/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        araliya: {
          50:  '#fdf2f6',
          100: '#fce8f0',
          200: '#f9d0e1',
          300: '#f4a8c7',
          400: '#ec74a4',
          500: '#c8476a',  // primary rose
          600: '#a83558',
          700: '#8a2347',
          800: '#6b1a38',
          900: '#3d0f22',
          950: '#1a0510',
        },
        gold: {
          300: '#f0c060',
          400: '#d4a04a',
          500: '#c9933a',
          600: '#a67830',
        }
      },
      fontFamily: {
        sans: ['var(--font-noto-sinhala)', 'var(--font-inter)', 'sans-serif'],
        display: ['var(--font-cormorant)', 'Georgia', 'serif'],
      },
      animation: {
        'fade-up': 'fadeUp 0.5s ease both',
        'fade-in': 'fadeIn 0.3s ease both',
        'slide-in': 'slideIn 0.4s cubic-bezier(0.34,1.56,0.64,1) both',
      },
      keyframes: {
        fadeUp: {
          from: { opacity: '0', transform: 'translateY(16px)' },
          to:   { opacity: '1', transform: 'translateY(0)' }
        },
        fadeIn: {
          from: { opacity: '0' },
          to:   { opacity: '1' }
        },
        slideIn: {
          from: { opacity: '0', transform: 'scale(0.92) translateY(12px)' },
          to:   { opacity: '1', transform: 'scale(1) translateY(0)' }
        }
      },
      boxShadow: {
        'rose': '0 4px 20px rgba(200,71,106,0.25)',
        'rose-lg': '0 8px 40px rgba(200,71,106,0.35)',
        'card': '0 2px 12px rgba(0,0,0,0.06)',
        'card-hover': '0 12px 40px rgba(200,71,106,0.15)',
      }
    }
  },
  plugins: []
}
