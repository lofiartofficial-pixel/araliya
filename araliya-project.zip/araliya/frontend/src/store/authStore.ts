import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import Cookies from 'js-cookie'
import { api } from '@/lib/api'

interface User {
  id: string
  email: string
  full_name: string
  phone?: string
  role: 'buyer' | 'supplier' | 'admin'
  is_active: boolean
  is_verified: boolean
  avatar_url?: string
}

interface AuthState {
  user: User | null
  accessToken: string | null
  refreshToken: string | null
  isLoading: boolean
  isAuthenticated: boolean

  login: (email: string, password: string) => Promise<void>
  register: (data: RegisterData) => Promise<void>
  logout: () => Promise<void>
  refreshTokens: () => Promise<boolean>
  fetchMe: () => Promise<void>
  setTokens: (access: string, refresh: string) => void
}

interface RegisterData {
  email: string
  password: string
  full_name: string
  phone?: string
  role?: 'buyer' | 'supplier'
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      accessToken: null,
      refreshToken: null,
      isLoading: false,
      isAuthenticated: false,

      setTokens: (access, refresh) => {
        Cookies.set('access_token', access, { secure: true, sameSite: 'strict', expires: 7 })
        Cookies.set('refresh_token', refresh, { secure: true, sameSite: 'strict', expires: 30 })
        set({ accessToken: access, refreshToken: refresh })
      },

      login: async (email, password) => {
        set({ isLoading: true })
        try {
          const { data } = await api.post('/auth/login', { email, password })
          const { user, accessToken, refreshToken } = data.data
          get().setTokens(accessToken, refreshToken)
          set({ user, isAuthenticated: true })
        } finally {
          set({ isLoading: false })
        }
      },

      register: async (formData) => {
        set({ isLoading: true })
        try {
          const { data } = await api.post('/auth/register', formData)
          const { user, accessToken, refreshToken } = data.data
          get().setTokens(accessToken, refreshToken)
          set({ user, isAuthenticated: true })
        } finally {
          set({ isLoading: false })
        }
      },

      logout: async () => {
        try {
          await api.post('/auth/logout')
        } catch {}
        Cookies.remove('access_token')
        Cookies.remove('refresh_token')
        set({ user: null, accessToken: null, refreshToken: null, isAuthenticated: false })
      },

      refreshTokens: async () => {
        const refreshToken = get().refreshToken || Cookies.get('refresh_token')
        if (!refreshToken) return false
        try {
          const { data } = await api.post('/auth/refresh', { refreshToken })
          get().setTokens(data.data.accessToken, data.data.refreshToken)
          return true
        } catch {
          get().logout()
          return false
        }
      },

      fetchMe: async () => {
        try {
          const { data } = await api.get('/auth/me')
          set({ user: data.data, isAuthenticated: true })
        } catch {
          set({ isAuthenticated: false })
        }
      }
    }),
    {
      name: 'araliya-auth',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        user: state.user,
        accessToken: state.accessToken,
        refreshToken: state.refreshToken,
        isAuthenticated: state.isAuthenticated
      })
    }
  )
)
