import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

const PROTECTED_ROUTES = ['/supplier', '/admin', '/buyer', '/profile']
const AUTH_ROUTES = ['/auth/login', '/auth/register']

const ROLE_ROUTES: Record<string, string[]> = {
  admin: ['/admin'],
  supplier: ['/supplier'],
  buyer: ['/buyer'],
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl
  const token = request.cookies.get('access_token')?.value

  const isProtected = PROTECTED_ROUTES.some(r => pathname.startsWith(r))
  const isAuthRoute = AUTH_ROUTES.some(r => pathname.startsWith(r))

  // Redirect to login if trying to access protected route without token
  if (isProtected && !token) {
    const loginUrl = new URL('/auth/login', request.url)
    loginUrl.searchParams.set('redirect', pathname)
    return NextResponse.redirect(loginUrl)
  }

  // Redirect to products if already logged in and trying to access auth routes
  if (isAuthRoute && token) {
    return NextResponse.redirect(new URL('/products', request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|uploads).*)',
  ]
}
