'use client'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Users, Package, ShoppingBag, DollarSign, CheckCircle, XCircle, Clock } from 'lucide-react'
import { adminApi } from '@/lib/api'
import Navbar from '@/components/Navbar'
import toast from 'react-hot-toast'
import { useState } from 'react'
import { clsx } from 'clsx'

type AdminTab = 'overview' | 'suppliers' | 'orders' | 'users'

export default function AdminDashboard() {
  const [tab, setTab] = useState<AdminTab>('overview')
  const qc = useQueryClient()

  const { data: dash } = useQuery({
    queryKey: ['admin-dashboard'],
    queryFn: () => adminApi.dashboard().then(r => r.data.data)
  })

  const { data: suppliersData } = useQuery({
    queryKey: ['admin-suppliers', 'pending'],
    queryFn: () => adminApi.suppliers({ approved: false }).then(r => r.data),
    enabled: tab === 'suppliers'
  })

  const { data: ordersData } = useQuery({
    queryKey: ['admin-orders'],
    queryFn: () => adminApi.orders({ limit: 20 }).then(r => r.data),
    enabled: tab === 'orders'
  })

  const { data: usersData } = useQuery({
    queryKey: ['admin-users'],
    queryFn: () => adminApi.users().then(r => r.data),
    enabled: tab === 'users'
  })

  const approveMutation = useMutation({
    mutationFn: ({ id, approved }: { id: string; approved: boolean }) =>
      adminApi.approveSupplier(id, { is_approved: approved }),
    onSuccess: (_, { approved }) => {
      toast.success(approved ? '✅ Supplier approved!' : '❌ Supplier rejected')
      qc.invalidateQueries({ queryKey: ['admin-suppliers'] })
      qc.invalidateQueries({ queryKey: ['admin-dashboard'] })
    }
  })

  const stats = dash?.stats

  const TABS: { key: AdminTab; label: string }[] = [
    { key: 'overview', label: '📊 Overview' },
    { key: 'suppliers', label: '🏭 Suppliers' },
    { key: 'orders', label: '📦 Orders' },
    { key: 'users', label: '👥 Users' },
  ]

  return (
    <div className="min-h-screen bg-stone-50">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <h1 className="font-display text-3xl font-light text-gray-900">
            Admin <em className="italic text-araliya-500">Dashboard</em>
          </h1>
          <p className="text-gray-500 text-sm">Araliya B2B Platform Management</p>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b border-gray-200 overflow-x-auto scrollbar-hide">
          {TABS.map(t => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={clsx(
                'px-5 py-2.5 text-sm font-medium whitespace-nowrap border-b-2 transition-all',
                tab === t.key
                  ? 'border-araliya-500 text-araliya-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              )}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* OVERVIEW */}
        {tab === 'overview' && (
          <div>
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
              {[
                { label: 'Users', value: stats?.total_users, icon: Users, color: 'bg-blue-100 text-blue-500' },
                { label: 'Suppliers', value: stats?.total_suppliers, icon: Package, color: 'bg-araliya-100 text-araliya-500', sub: `${stats?.pending_suppliers} pending` },
                { label: 'Products', value: stats?.total_products, icon: Package, color: 'bg-purple-100 text-purple-500' },
                { label: 'Orders', value: stats?.total_orders, icon: ShoppingBag, color: 'bg-amber-100 text-amber-500' },
                { label: 'Revenue', value: `රු. ${((stats?.total_revenue || 0) / 1000).toFixed(0)}k`, icon: DollarSign, color: 'bg-emerald-100 text-emerald-500' },
              ].map((s, i) => (
                <div key={i} className="card p-5">
                  <div className={clsx('w-10 h-10 rounded-xl flex items-center justify-center mb-3', s.color)}>
                    <s.icon className="w-5 h-5" />
                  </div>
                  <p className="text-2xl font-bold text-gray-800">{s.value ?? '—'}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{s.label}</p>
                  {s.sub && <p className="text-xs text-araliya-500 font-medium">{s.sub}</p>}
                </div>
              ))}
            </div>

            {/* Recent orders preview */}
            <div className="card p-6">
              <h2 className="font-semibold text-gray-800 mb-4">මෑත ඇණවුම්</h2>
              <div className="space-y-2">
                {(dash?.recent_orders || []).slice(0, 5).map((o: any) => (
                  <div key={o.id} className="flex items-center justify-between py-2 border-b border-gray-50">
                    <span className="font-mono text-xs text-gray-500">{o.order_number || o.id?.slice(0, 8)}</span>
                    <span className="text-sm font-semibold text-gray-700">රු. {parseFloat(o.total_amount).toLocaleString()}</span>
                    <span className="badge badge-gray text-xs">{o.status}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* SUPPLIERS */}
        {tab === 'suppliers' && (
          <div className="card p-6">
            <h2 className="font-semibold text-gray-800 mb-4">Pending Supplier Approvals</h2>
            {(suppliersData?.data || []).length === 0 ? (
              <p className="text-gray-400 text-sm text-center py-8">Pending suppliers නොමැත</p>
            ) : (
              <div className="space-y-3">
                {(suppliersData?.data || []).map((s: any) => (
                  <div key={s.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
                    <div className="flex-1">
                      <p className="font-semibold text-gray-800">{s.business_name}</p>
                      <p className="text-xs text-gray-500">{s.users?.email} · {s.category} · {s.city}</p>
                      <p className="text-xs text-gray-400 mt-1 line-clamp-1">{s.description}</p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => approveMutation.mutate({ id: s.id, approved: true })}
                        className="flex items-center gap-1 px-3 py-1.5 bg-emerald-500 text-white rounded-lg text-xs font-medium hover:bg-emerald-600 transition-colors"
                      >
                        <CheckCircle className="w-3.5 h-3.5" />
                        Approve
                      </button>
                      <button
                        onClick={() => approveMutation.mutate({ id: s.id, approved: false })}
                        className="flex items-center gap-1 px-3 py-1.5 bg-red-500 text-white rounded-lg text-xs font-medium hover:bg-red-600 transition-colors"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        Reject
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ORDERS */}
        {tab === 'orders' && (
          <div className="card p-6">
            <h2 className="font-semibold text-gray-800 mb-4">සියලු ඇණවුම්</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-100">
                    {['Order #', 'Buyer', 'Supplier', 'Amount', 'Payment', 'Status'].map(h => (
                      <th key={h} className="text-left py-2 pr-4 text-xs font-semibold text-gray-500">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(ordersData?.data || []).map((o: any) => (
                    <tr key={o.id} className="border-b border-gray-50 hover:bg-araliya-50/30 transition-colors">
                      <td className="py-3 pr-4 font-mono text-xs">{o.order_number}</td>
                      <td className="py-3 pr-4 text-gray-700">{o.buyers?.full_name}</td>
                      <td className="py-3 pr-4 text-gray-600">{o.suppliers?.business_name}</td>
                      <td className="py-3 pr-4 font-semibold">රු. {parseFloat(o.total_amount).toLocaleString()}</td>
                      <td className="py-3 pr-4">
                        <span className={clsx('badge', o.payment_status === 'paid' ? 'badge-green' : 'badge-gold')}>
                          {o.payment_status}
                        </span>
                      </td>
                      <td className="py-3">
                        <span className="badge badge-gray">{o.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* USERS */}
        {tab === 'users' && (
          <div className="card p-6">
            <h2 className="font-semibold text-gray-800 mb-4">සියලු Users</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-100">
                    {['Name', 'Email', 'Role', 'Active', 'Joined'].map(h => (
                      <th key={h} className="text-left py-2 pr-4 text-xs font-semibold text-gray-500">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(usersData?.data || []).map((u: any) => (
                    <tr key={u.id} className="border-b border-gray-50 hover:bg-araliya-50/30 transition-colors">
                      <td className="py-3 pr-4 font-medium">{u.full_name}</td>
                      <td className="py-3 pr-4 text-gray-500 text-xs">{u.email}</td>
                      <td className="py-3 pr-4">
                        <span className={clsx('badge', u.role === 'admin' ? 'badge-red' : u.role === 'supplier' ? 'badge-gold' : 'badge-blue')}>
                          {u.role}
                        </span>
                      </td>
                      <td className="py-3 pr-4">
                        <span className={clsx('badge', u.is_active ? 'badge-green' : 'badge-gray')}>
                          {u.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </td>
                      <td className="py-3 text-gray-400 text-xs">
                        {new Date(u.created_at).toLocaleDateString('si-LK')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
