'use client'
import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Search, SlidersHorizontal, Grid, List } from 'lucide-react'
import { productsApi } from '@/lib/api'
import ProductCard from '@/components/ProductCard'
import Navbar from '@/components/Navbar'
import { clsx } from 'clsx'

const CATEGORIES = [
  { value: '', label: 'සියල්ල' },
  { value: 'skin', label: '🧴 සම' },
  { value: 'hair', label: '💆 කෙස්' },
  { value: 'makeup', label: '💄 Makeup' },
  { value: 'fragrance', label: '🌸 සුවඳ' },
  { value: 'organic', label: '🌿 Organic' },
  { value: 'nail', label: '💅 Nail' },
]

export default function ProductsPage() {
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('')
  const [sort, setSort] = useState('created_at')
  const [page, setPage] = useState(1)
  const [view, setView] = useState<'grid' | 'list'>('grid')

  const { data, isLoading, error } = useQuery({
    queryKey: ['products', { search, category, sort, page }],
    queryFn: () => productsApi.list({ search, category, sort, page, limit: 12 }).then(r => r.data)
  })

  const products = data?.data || []
  const pagination = data?.pagination

  return (
    <div className="min-h-screen bg-stone-50">
      <Navbar />

      {/* Page Header */}
      <div className="page-header">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="font-display text-4xl md:text-5xl font-light text-white mb-2">
            රූපලාවන්‍ය <em className="italic text-gold-300">නිෂ්පාදන</em>
          </h1>
          <p className="text-araliya-300 text-sm">Bulk ගණනින් ශ්‍රේෂ්ඨ suppliers ගෙන්</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filter Bar */}
        <div className="bg-white rounded-2xl p-4 shadow-card mb-6 flex flex-wrap gap-3 items-center">
          {/* Search */}
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1) }}
              placeholder="නිෂ්පාදනය සොයන්න..."
              className="form-input pl-10"
            />
          </div>

          {/* Category pills */}
          <div className="flex gap-2 flex-wrap">
            {CATEGORIES.map(cat => (
              <button
                key={cat.value}
                onClick={() => { setCategory(cat.value); setPage(1) }}
                className={clsx(
                  'px-4 py-2 rounded-full text-sm font-medium transition-all',
                  category === cat.value
                    ? 'bg-araliya-500 text-white shadow-rose'
                    : 'bg-gray-100 text-gray-600 hover:bg-araliya-50 hover:text-araliya-600'
                )}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Sort */}
          <select
            value={sort}
            onChange={e => setSort(e.target.value)}
            className="form-input w-auto text-sm"
          >
            <option value="created_at">නවතම</option>
            <option value="price">මිල: අඩු → වැඩි</option>
            <option value="rating">ශ්‍රේණිගත කිරීම</option>
          </select>

          {/* View toggle */}
          <div className="flex gap-1 bg-gray-100 rounded-lg p-1">
            <button
              onClick={() => setView('grid')}
              className={clsx('p-1.5 rounded', view === 'grid' ? 'bg-white shadow text-araliya-500' : 'text-gray-500')}
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setView('list')}
              className={clsx('p-1.5 rounded', view === 'list' ? 'bg-white shadow text-araliya-500' : 'text-gray-500')}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Results count */}
        <p className="text-sm text-gray-500 mb-4">
          <span className="text-araliya-500 font-semibold">{pagination?.total || 0}</span> නිෂ්පාදන හමු විය
        </p>

        {/* Products Grid */}
        {isLoading ? (
          <div className={clsx(
            'grid gap-4',
            view === 'grid' ? 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4' : 'grid-cols-1'
          )}>
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="card h-72 animate-pulse bg-gray-100 rounded-2xl" />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-4xl mb-3">🌸</div>
            <p className="text-gray-500">නිෂ්පාදන හමු නොවිණ</p>
          </div>
        ) : (
          <div className={clsx(
            'grid gap-4',
            view === 'grid' ? 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4' : 'grid-cols-1'
          )}>
            {products.map((product: any, i: number) => (
              <ProductCard key={product.id} product={product} index={i} listView={view === 'list'} />
            ))}
          </div>
        )}

        {/* Pagination */}
        {pagination && pagination.pages > 1 && (
          <div className="flex justify-center gap-2 mt-10">
            {Array.from({ length: pagination.pages }, (_, i) => i + 1).map(p => (
              <button
                key={p}
                onClick={() => setPage(p)}
                className={clsx(
                  'w-9 h-9 rounded-full text-sm font-medium transition-all',
                  page === p
                    ? 'bg-araliya-500 text-white shadow-rose'
                    : 'bg-white text-gray-600 hover:bg-araliya-50 border border-gray-200'
                )}
              >
                {p}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
