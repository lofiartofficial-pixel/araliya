'use client'
import { useQuery } from '@tanstack/react-query'
import { Package, ShoppingBag, DollarSign, TrendingUp, Plus, Eye } from 'lucide-react'
import Link from 'next/link'
import { suppliersApi, ordersApi } from '@/lib/api'
import Navbar from '@/components/Navbar'
import { useAuthStore } from '@/store/authStore'

const STATUS_BADGE: Record<string, string> = {
  pending:    'badge badge-gold',
  confirmed:  'badge badge-blue',
  processing: 'badge badge-blue',
  shipped:    'badge badge-green',
  delivered:  'badge badge-green',
  cancelled:  'badge badge-red',
}

export default function SupplierDashboard() {
  const { user } = useAuthStore()

  const { data: dashData, isLoading } = useQuery({
    queryKey: ['supplier-dashboard'],
    queryFn: () => suppliersApi.dashboard().then(r => r.data.data)
  })

  const { data: ordersData } = useQuery({
    queryKey: ['supplier-orders'],
    queryFn: () => ordersApi.list({ limit: 5 }).then(r => r.data)
  })

  const stats = dashData?.stats
  const orders = ordersData?.data || []

  if (isLoading) {
    return (
      <div className="min-h-screen bg-stone-50">
        <Navbar />
        <div className="flex items-center justify-center h-64">
          <div className="text-4xl animate-pulse">🌺</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-stone-50">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-display text-3xl font-light text-gray-900">
              ආයුබෝවන්, <em className="italic text-araliya-500">{user?.full_name?.split(' ')[0]}</em>
            </h1>
            <p className="text-gray-500 text-sm mt-1">{dashData?.supplier?.business_name}</p>
          </div>
          <Link href="/supplier/products/new" className="btn-primary gap-2">
            <Plus className="w-4 h-4" />
            නිෂ්පාදනයක් එකතු කරන්න
          </Link>
        </div>

        {/* Stats cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="card p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-araliya-100 rounded-xl flex items-center justify-center">
                <Package className="w-5 h-5 text-araliya-500" />
              </div>
              <span className="text-xs text-gray-400">නිෂ්පාදන</span>
            </div>
            <p className="text-2xl font-bold text-gray-800">{stats?.total_products || 0}</p>
            <p className="text-xs text-gray-500 mt-1">{stats?.active_products || 0} active</p>
          </div>

          <div className="card p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                <ShoppingBag className="w-5 h-5 text-blue-500" />
              </div>
              <span className="text-xs text-gray-400">ඇණවුම්</span>
            </div>
            <p className="text-2xl font-bold text-gray-800">{stats?.total_orders || 0}</p>
            <p className="text-xs text-gray-500 mt-1">{stats?.order_status?.pending || 0} pending</p>
          </div>

          <div className="card p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-emerald-100 rounded-xl flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-emerald-500" />
              </div>
              <span className="text-xs text-gray-400">ආදායම</span>
            </div>
            <p className="text-2xl font-bold text-gray-800">
              රු. {((stats?.total_revenue || 0) / 1000).toFixed(0)}k
            </p>
            <p className="text-xs text-gray-500 mt-1">paid orders</p>
          </div>

          <div className="card p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-amber-500" />
              </div>
              <span className="text-xs text-gray-400">ශ්‍රේණිය</span>
            </div>
            <p className="text-2xl font-bold text-gray-800">{dashData?.supplier?.rating || '—'}</p>
            <p className="text-xs text-gray-500 mt-1">/ 5.0 rating</p>
          </div>
        </div>

        {/* Recent Orders */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-gray-800">මෑත ඇණවුම්</h2>
            <Link href="/supplier/orders" className="text-sm text-araliya-500 hover:underline">
              සියල්ල බලන්න →
            </Link>
          </div>

          {orders.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <ShoppingBag className="w-8 h-8 mx-auto mb-2 opacity-30" />
              <p className="text-sm">ඇණවුම් නොමැත</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="text-left py-2 pr-4 text-xs font-semibold text-gray-500">Order #</th>
                    <th className="text-left py-2 pr-4 text-xs font-semibold text-gray-500">Buyer</th>
                    <th className="text-left py-2 pr-4 text-xs font-semibold text-gray-500">Total</th>
                    <th className="text-left py-2 pr-4 text-xs font-semibold text-gray-500">Status</th>
                    <th className="text-left py-2 text-xs font-semibold text-gray-500">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order: any) => (
                    <tr key={order.id} className="border-b border-gray-50 hover:bg-araliya-50/50 transition-colors">
                      <td className="py-3 pr-4 font-mono text-xs text-gray-600">{order.order_number}</td>
                      <td className="py-3 pr-4 text-gray-700">{order.buyers?.full_name}</td>
                      <td className="py-3 pr-4 font-semibold text-gray-800">
                        රු. {parseFloat(order.total_amount).toLocaleString()}
                      </td>
                      <td className="py-3 pr-4">
                        <span className={STATUS_BADGE[order.status] || 'badge badge-gray'}>
                          {order.status}
                        </span>
                      </td>
                      <td className="py-3">
                        <Link
                          href={`/supplier/orders/${order.id}`}
                          className="text-araliya-500 hover:text-araliya-700 transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
