import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { Cormorant_Garamond } from 'next/font/google'
import './globals.css'
import { Providers } from '@/components/Providers'
import { Toaster } from 'react-hot-toast'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap'
})

const cormorant = Cormorant_Garamond({
  subsets: ['latin'],
  variable: '--font-cormorant',
  weight: ['300', '400', '500', '600', '700'],
  style: ['normal', 'italic'],
  display: 'swap'
})

export const metadata: Metadata = {
  title: 'Araliya 🌺 — B2B Beauty Marketplace Sri Lanka',
  description: 'ශ්‍රී ලංකාවේ රූපලාවන්‍ය ව්‍යාපාරිකයන් සඳහා B2B platform',
  keywords: ['beauty', 'B2B', 'cosmetics', 'Sri Lanka', 'wholesale', 'supplier'],
  openGraph: {
    title: 'Araliya — B2B Beauty Marketplace',
    description: 'Sri Lanka\'s premier beauty B2B marketplace',
    type: 'website',
  }
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="si" className={`${inter.variable} ${cormorant.variable}`}>
      <body className="bg-stone-50 text-gray-900 antialiased">
        <Providers>
          {children}
          <Toaster
            position="bottom-right"
            toastOptions={{
              style: {
                fontFamily: 'var(--font-inter), sans-serif',
                fontSize: '0.875rem',
              },
              success: {
                iconTheme: { primary: '#c8476a', secondary: '#fff' }
              }
            }}
          />
        </Providers>
      </body>
    </html>
  )
}
