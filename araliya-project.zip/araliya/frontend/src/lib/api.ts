import axios from 'axios'
import Cookies from 'js-cookie'
import toast from 'react-hot-toast'

export const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api',
  headers: { 'Content-Type': 'application/json' },
  timeout: 15000
})

// Request interceptor — attach token
api.interceptors.request.use((config) => {
  const token = Cookies.get('access_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// Response interceptor — handle 401 & refresh
let isRefreshing = false
let failedQueue: { resolve: Function; reject: Function }[] = []

const processQueue = (error: any, token: string | null = null) => {
  failedQueue.forEach(({ resolve, reject }) => {
    if (error) reject(error)
    else resolve(token)
  })
  failedQueue = []
}

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config

    if (error.response?.status === 401 && !originalRequest._retry) {
      if (error.response?.data?.code === 'TOKEN_EXPIRED') {
        if (isRefreshing) {
          return new Promise((resolve, reject) => {
            failedQueue.push({ resolve, reject })
          }).then((token) => {
            originalRequest.headers.Authorization = `Bearer ${token}`
            return api(originalRequest)
          })
        }

        originalRequest._retry = true
        isRefreshing = true

        try {
          const refreshToken = Cookies.get('refresh_token')
          const { data } = await axios.post(
            `${process.env.NEXT_PUBLIC_API_URL}/auth/refresh`,
            { refreshToken }
          )
          const { accessToken } = data.data
          Cookies.set('access_token', accessToken, { secure: true, sameSite: 'strict', expires: 7 })
          processQueue(null, accessToken)
          originalRequest.headers.Authorization = `Bearer ${accessToken}`
          return api(originalRequest)
        } catch (refreshError) {
          processQueue(refreshError, null)
          Cookies.remove('access_token')
          Cookies.remove('refresh_token')
          window.location.href = '/auth/login'
          return Promise.reject(refreshError)
        } finally {
          isRefreshing = false
        }
      }
    }

    // Show error toast for non-auth errors
    const message = error.response?.data?.message || 'Something went wrong'
    if (error.response?.status >= 500) {
      toast.error('Server error. Please try again.')
    } else if (error.response?.status !== 401) {
      // Let components handle 401
    }

    return Promise.reject(error)
  }
)

// ── API Helper Functions ─────────────────────────────────────

export const productsApi = {
  list: (params?: object) => api.get('/products', { params }),
  get: (id: string) => api.get(`/products/${id}`),
  create: (data: object) => api.post('/products', data),
  update: (id: string, data: object) => api.put(`/products/${id}`, data),
  delete: (id: string) => api.delete(`/products/${id}`)
}

export const ordersApi = {
  list: (params?: object) => api.get('/orders', { params }),
  get: (id: string) => api.get(`/orders/${id}`),
  create: (data: object) => api.post('/orders', data),
  updateStatus: (id: string, status: string, notes?: string) =>
    api.patch(`/orders/${id}/status`, { status, notes })
}

export const suppliersApi = {
  list: (params?: object) => api.get('/suppliers', { params }),
  get: (id: string) => api.get(`/suppliers/${id}`),
  register: (data: object) => api.post('/suppliers/register', data),
  dashboard: () => api.get('/suppliers/me/dashboard'),
  update: (data: object) => api.put('/suppliers/me', data)
}

export const adminApi = {
  dashboard: () => api.get('/admin/dashboard'),
  users: (params?: object) => api.get('/admin/users', { params }),
  updateUser: (id: string, data: object) => api.patch(`/admin/users/${id}`, data),
  suppliers: (params?: object) => api.get('/admin/suppliers', { params }),
  approveSupplier: (id: string, data: object) => api.patch(`/admin/suppliers/${id}/approve`, data),
  orders: (params?: object) => api.get('/admin/orders', { params }),
  products: () => api.get('/admin/products'),
  featureProduct: (id: string, featured: boolean) => api.patch(`/admin/products/${id}/feature`, { is_featured: featured })
}

export const uploadApi = {
  image: (file: File) => {
    const form = new FormData()
    form.append('image', file)
    return api.post('/upload/image', form, { headers: { 'Content-Type': 'multipart/form-data' } })
  },
  multiple: (files: File[]) => {
    const form = new FormData()
    files.forEach(f => form.append('images', f))
    return api.post('/upload/multiple', form, { headers: { 'Content-Type': 'multipart/form-data' } })
  }
}
