# 🌺 Araliya — B2B Beauty Marketplace

ශ්‍රී ලංකාවේ රූපලාවන්‍ය ව්‍යාපාරිකයන් සඳහා production-ready B2B platform.

## 🏗️ Tech Stack

| Layer     | Technology                          |
|-----------|-------------------------------------|
| Frontend  | Next.js 14 + TypeScript + Tailwind CSS |
| Backend   | Express.js (ES Modules)             |
| Database  | Supabase (PostgreSQL)               |
| Auth      | JWT (Access + Refresh tokens)       |
| WhatsApp  | Twilio WhatsApp Business API        |
| State     | Zustand + React Query               |
| Uploads   | Multer + Sharp (image optimization) |

## 📁 Project Structure

```
araliya/
├── backend/
│   ├── src/
│   │   ├── server.js              # Express entry point
│   │   ├── db/
│   │   │   ├── supabase.js        # Supabase client
│   │   │   └── schema.sql         # Database schema (run in Supabase)
│   │   ├── middleware/
│   │   │   └── auth.js            # JWT auth middleware
│   │   ├── routes/
│   │   │   ├── auth.js            # Login, register, refresh
│   │   │   ├── products.js        # Product CRUD + search
│   │   │   ├── orders.js          # Order management
│   │   │   ├── suppliers.js       # Supplier profiles
│   │   │   ├── admin.js           # Admin panel routes
│   │   │   └── upload.js          # Image upload
│   │   └── services/
│   │       └── whatsapp.js        # WhatsApp notifications
│   └── package.json
│
└── frontend/
    ├── src/
    │   ├── app/
    │   │   ├── layout.tsx          # Root layout
    │   │   ├── globals.css         # Design system CSS
    │   │   ├── auth/login/         # Login page
    │   │   ├── products/           # Product catalog
    │   │   ├── supplier/dashboard/ # Supplier panel
    │   │   └── admin/              # Admin dashboard
    │   ├── components/
    │   │   ├── Navbar.tsx
    │   │   ├── ProductCard.tsx
    │   │   └── Providers.tsx
    │   ├── store/
    │   │   └── authStore.ts        # Zustand auth state
    │   ├── lib/
    │   │   └── api.ts              # Axios client + API helpers
    │   └── middleware.ts           # Route guards
    └── package.json
```

## 🚀 Setup Guide

### 1. Supabase Database
1. [supabase.com](https://supabase.com) → New project
2. SQL Editor → `backend/src/db/schema.sql` paste කරන්න → Run
3. Project Settings → API → URL සහ Keys copy කරන්න

### 2. Twilio WhatsApp (Optional)
1. [twilio.com](https://twilio.com) → Account create කරන්න
2. WhatsApp Sandbox enable කරන්න
3. Account SID + Auth Token copy කරන්න

### 3. Backend Setup
```bash
cd backend
cp .env.example .env
# .env file edit කරන්න (Supabase + Twilio credentials)
npm install
npm run dev
# → http://localhost:5000/api/health
```

### 4. Frontend Setup
```bash
cd frontend
cp .env.example .env.local
npm install
npm run dev
# → http://localhost:3000
```

## 🔐 User Roles

| Role     | Access                                    |
|----------|-------------------------------------------|
| buyer    | Products browse, place orders, order history |
| supplier | Product CRUD, order management, dashboard |
| admin    | Full access, approve suppliers, all data  |

## 🌐 API Endpoints

```
POST /api/auth/register     Register new user
POST /api/auth/login        Login
POST /api/auth/refresh      Refresh access token
POST /api/auth/logout       Logout
GET  /api/auth/me           Get current user

GET  /api/products          List products (with search/filter)
GET  /api/products/:id      Get single product
POST /api/products          Create product (supplier)
PUT  /api/products/:id      Update product
DELETE /api/products/:id    Soft delete

GET  /api/suppliers         List approved suppliers
POST /api/suppliers/register  Register supplier profile
GET  /api/suppliers/me/dashboard  Supplier stats

POST /api/orders            Place order (buyer)
GET  /api/orders            List orders (role-scoped)
PATCH /api/orders/:id/status  Update status (supplier/admin)

GET  /api/admin/dashboard   Admin stats
GET  /api/admin/suppliers   All suppliers
PATCH /api/admin/suppliers/:id/approve  Approve/reject

POST /api/upload/image      Upload single image
POST /api/upload/multiple   Upload multiple images
```

## 📱 WhatsApp Notifications

- **New order** → Supplier WhatsApp notify
- **Status update** → Buyer WhatsApp notify
- **Twilio sandbox** mode works for development

## 🚢 Production Deployment

**Backend** → Railway.app / Render.com
```bash
npm start
```

**Frontend** → Vercel
```bash
npm run build
vercel --prod
```

**Environment variables** production සඳහා update කරන්න.

---

Built with 🌺 for Sri Lanka's beauty industry
