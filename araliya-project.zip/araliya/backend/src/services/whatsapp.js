import twilio from 'twilio'
import dotenv from 'dotenv'
dotenv.config()

let client = null

// Only init Twilio if credentials are set
if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN &&
    process.env.TWILIO_ACCOUNT_SID !== 'your-twilio-account-sid') {
  client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN)
}

/**
 * Send a WhatsApp message via Twilio
 * @param {object} options
 * @param {string} options.to   - WhatsApp number e.g. "whatsapp:+94771234567" or null
 * @param {string} options.message - Message text (max 1600 chars)
 */
export const sendWhatsAppNotification = async ({ to, message }) => {
  if (!client) {
    console.log('📱 [WhatsApp Mock]', to, '\n', message)
    return { success: true, mock: true }
  }

  if (!to) {
    console.warn('⚠️ WhatsApp: No recipient number provided, skipping.')
    return { success: false, reason: 'no_recipient' }
  }

  try {
    const result = await client.messages.create({
      from: process.env.TWILIO_WHATSAPP_FROM,
      to,
      body: message.slice(0, 1600)
    })

    console.log('✅ WhatsApp sent:', result.sid)
    return { success: true, sid: result.sid }
  } catch (err) {
    console.error('❌ WhatsApp error:', err.message)
    return { success: false, error: err.message }
  }
}

/**
 * Send order confirmation to supplier
 */
export const notifySupplierNewOrder = async (order, supplier, buyer, items) => {
  const itemsList = items.map(i => `• ${i.name} × ${i.quantity} = LKR ${(i.unit_price * i.quantity).toLocaleString()}`).join('\n')
  return sendWhatsAppNotification({
    to: supplier.whatsapp,
    message: `🌺 *Araliya — නව ඇණවුමක්!*\n\n📋 Order: *${order.order_number}*\n👤 Buyer: ${buyer.full_name} (${buyer.phone})\n\n📦 Items:\n${itemsList}\n\n💰 Total: *LKR ${order.total_amount.toLocaleString()}*\n📍 Delivery: ${order.delivery_address}\n💳 Payment: ${order.payment_method}\n\n🔗 Manage: https://araliya.lk/supplier/orders`
  })
}

/**
 * Send status update to buyer
 */
export const notifyBuyerStatusUpdate = async (order, buyer, newStatus, supplierName) => {
  const statusMessages = {
    confirmed: `✅ ඔබේ ඇණවුම *${order.order_number}* confirm කළා!`,
    processing: `⚙️ ඔබේ ඇණවුම *${order.order_number}* process වෙමින් පවතී.`,
    shipped: `🚚 ඔබේ ඇණවුම *${order.order_number}* ship කළා! ඉක්මනින් ලැබේ.`,
    delivered: `🎉 ඔබේ ඇණවුම *${order.order_number}* deliver කළා! ස්තූතියි 🌸`,
    cancelled: `❌ ඔබේ ඇණවුම *${order.order_number}* cancel කළා. Questions? +94771234567`
  }

  return sendWhatsAppNotification({
    to: buyer.phone ? `whatsapp:+94${buyer.phone.replace(/^0/, '')}` : null,
    message: `🌺 *Araliya Update*\n\n${statusMessages[newStatus] || 'Status updated.'}\n\nFrom: ${supplierName}\n\n🔗 https://araliya.lk/orders`
  })
}
