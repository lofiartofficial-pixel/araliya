import { Router } from 'express'
import { body, query, validationResult } from 'express-validator'
import { supabaseAdmin } from '../db/supabase.js'
import { authenticate, authorize, optionalAuth } from '../middleware/auth.js'

const router = Router()

// ── GET /api/products ─────────────────────────────────────────
// Public: list products with search, filter, sort, pagination
router.get('/', optionalAuth, async (req, res) => {
  try {
    const {
      search = '',
      category = '',
      supplier_id = '',
      min_price = '',
      max_price = '',
      sort = 'created_at',
      order = 'desc',
      page = 1,
      limit = 12,
      featured = ''
    } = req.query

    let queryBuilder = supabaseAdmin
      .from('products')
      .select(`
        id, name, name_si, description, category, price, moq, stock,
        unit, images, tags, is_featured, rating, review_count, created_at,
        suppliers ( id, business_name, city, logo_url, rating, is_approved )
      `, { count: 'exact' })
      .eq('is_active', true)

    // Filter: suppliers must be approved (public listing)
    if (!req.user || req.user.role === 'buyer') {
      queryBuilder = queryBuilder.eq('suppliers.is_approved', true)
    }

    if (search) {
      queryBuilder = queryBuilder.or(`name.ilike.%${search}%,description.ilike.%${search}%,tags.cs.{${search}}`)
    }
    if (category) queryBuilder = queryBuilder.eq('category', category)
    if (supplier_id) queryBuilder = queryBuilder.eq('supplier_id', supplier_id)
    if (min_price) queryBuilder = queryBuilder.gte('price', parseFloat(min_price))
    if (max_price) queryBuilder = queryBuilder.lte('price', parseFloat(max_price))
    if (featured === 'true') queryBuilder = queryBuilder.eq('is_featured', true)

    const validSorts = ['price', 'rating', 'created_at', 'review_count']
    const sortField = validSorts.includes(sort) ? sort : 'created_at'
    queryBuilder = queryBuilder.order(sortField, { ascending: order === 'asc' })

    const pageNum = Math.max(1, parseInt(page))
    const limitNum = Math.min(50, parseInt(limit))
    const from = (pageNum - 1) * limitNum
    queryBuilder = queryBuilder.range(from, from + limitNum - 1)

    const { data, error, count } = await queryBuilder
    if (error) throw error

    res.json({
      success: true,
      data,
      pagination: {
        total: count,
        page: pageNum,
        limit: limitNum,
        pages: Math.ceil(count / limitNum)
      }
    })
  } catch (err) {
    console.error('Products fetch error:', err)
    res.status(500).json({ success: false, message: 'Failed to fetch products' })
  }
})

// ── GET /api/products/:id ─────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const { data, error } = await supabaseAdmin
      .from('products')
      .select(`
        *,
        suppliers ( id, business_name, city, logo_url, rating, whatsapp, description, is_approved )
      `)
      .eq('id', req.params.id)
      .eq('is_active', true)
      .single()

    if (error || !data) {
      return res.status(404).json({ success: false, message: 'Product not found' })
    }

    res.json({ success: true, data })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch product' })
  }
})

// ── POST /api/products ────────────────────────────────────────
// Supplier: create product
router.post('/', authenticate, authorize('supplier', 'admin'), [
  body('name').trim().isLength({ min: 2 }),
  body('category').isIn(['skin', 'hair', 'makeup', 'fragrance', 'organic', 'nail', 'other']),
  body('price').isFloat({ min: 0.01 }),
  body('moq').isInt({ min: 1 }),
  body('stock').optional().isInt({ min: 0 })
], async (req, res) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() })
  }

  try {
    // Get supplier id
    const { data: supplier } = await supabaseAdmin
      .from('suppliers')
      .select('id, is_approved')
      .eq('user_id', req.user.id)
      .single()

    if (!supplier) {
      return res.status(403).json({ success: false, message: 'Supplier profile required' })
    }

    const { name, name_si, description, category, price, moq, stock = 0, unit = 'unit', images = [], tags = [] } = req.body

    const { data, error } = await supabaseAdmin
      .from('products')
      .insert({ supplier_id: supplier.id, name, name_si, description, category, price, moq, stock, unit, images, tags })
      .select()
      .single()

    if (error) throw error

    res.status(201).json({ success: true, message: 'Product created', data })
  } catch (err) {
    console.error('Create product error:', err)
    res.status(500).json({ success: false, message: 'Failed to create product' })
  }
})

// ── PUT /api/products/:id ─────────────────────────────────────
router.put('/:id', authenticate, authorize('supplier', 'admin'), async (req, res) => {
  try {
    const { data: product } = await supabaseAdmin
      .from('products')
      .select('supplier_id, suppliers(user_id)')
      .eq('id', req.params.id)
      .single()

    if (!product) return res.status(404).json({ success: false, message: 'Product not found' })

    // Only owner or admin can update
    if (req.user.role !== 'admin' && product.suppliers?.user_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Not authorized' })
    }

    const allowed = ['name', 'name_si', 'description', 'price', 'moq', 'stock', 'unit', 'images', 'tags', 'is_active']
    const updates = Object.fromEntries(Object.entries(req.body).filter(([k]) => allowed.includes(k)))

    const { data, error } = await supabaseAdmin
      .from('products')
      .update(updates)
      .eq('id', req.params.id)
      .select()
      .single()

    if (error) throw error
    res.json({ success: true, data })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update product' })
  }
})

// ── DELETE /api/products/:id ──────────────────────────────────
router.delete('/:id', authenticate, authorize('supplier', 'admin'), async (req, res) => {
  try {
    await supabaseAdmin
      .from('products')
      .update({ is_active: false })
      .eq('id', req.params.id)

    res.json({ success: true, message: 'Product removed' })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete product' })
  }
})

export default router
