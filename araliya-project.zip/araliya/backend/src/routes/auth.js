import { Router } from 'express'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { v4 as uuidv4 } from 'uuid'
import { body, validationResult } from 'express-validator'
import { supabaseAdmin } from '../db/supabase.js'
import { authenticate } from '../middleware/auth.js'

const router = Router()

// ── Helper: Generate Tokens ──────────────────────────────────
const generateTokens = (userId, role) => {
  const accessToken = jwt.sign(
    { userId, role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  )
  const refreshToken = jwt.sign(
    { userId, tokenId: uuidv4() },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '30d' }
  )
  return { accessToken, refreshToken }
}

// ── POST /api/auth/register ──────────────────────────────────
router.post('/register', [
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('password').isLength({ min: 8 }).withMessage('Password min 8 characters'),
  body('full_name').trim().isLength({ min: 2 }).withMessage('Full name required'),
  body('phone').optional().isMobilePhone(),
  body('role').optional().isIn(['buyer', 'supplier']).withMessage('Invalid role')
], async (req, res) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() })
  }

  try {
    const { email, password, full_name, phone, role = 'buyer' } = req.body

    // Check existing user
    const { data: existing } = await supabaseAdmin
      .from('users')
      .select('id')
      .eq('email', email)
      .single()

    if (existing) {
      return res.status(409).json({ success: false, message: 'Email already registered' })
    }

    const password_hash = await bcrypt.hash(password, 12)

    const { data: user, error } = await supabaseAdmin
      .from('users')
      .insert({ email, password_hash, full_name, phone, role })
      .select('id, email, full_name, role, is_active, is_verified')
      .single()

    if (error) throw error

    const { accessToken, refreshToken } = generateTokens(user.id, user.role)

    // Store refresh token
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
    await supabaseAdmin.from('refresh_tokens').insert({
      user_id: user.id,
      token: refreshToken,
      expires_at: expiresAt.toISOString()
    })

    res.status(201).json({
      success: true,
      message: 'Registration successful',
      data: { user, accessToken, refreshToken }
    })
  } catch (err) {
    console.error('Register error:', err)
    res.status(500).json({ success: false, message: 'Registration failed' })
  }
})

// ── POST /api/auth/login ─────────────────────────────────────
router.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty()
], async (req, res) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() })
  }

  try {
    const { email, password } = req.body

    const { data: user } = await supabaseAdmin
      .from('users')
      .select('id, email, full_name, role, is_active, is_verified, password_hash')
      .eq('email', email)
      .single()

    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' })
    }

    if (!user.is_active) {
      return res.status(403).json({ success: false, message: 'Account deactivated' })
    }

    const isValid = await bcrypt.compare(password, user.password_hash)
    if (!isValid) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' })
    }

    const { accessToken, refreshToken } = generateTokens(user.id, user.role)

    // Cleanup old tokens + store new
    await supabaseAdmin.from('refresh_tokens').delete().eq('user_id', user.id)
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
    await supabaseAdmin.from('refresh_tokens').insert({
      user_id: user.id,
      token: refreshToken,
      expires_at: expiresAt.toISOString()
    })

    const { password_hash, ...safeUser } = user

    res.json({
      success: true,
      message: 'Login successful',
      data: { user: safeUser, accessToken, refreshToken }
    })
  } catch (err) {
    console.error('Login error:', err)
    res.status(500).json({ success: false, message: 'Login failed' })
  }
})

// ── POST /api/auth/refresh ───────────────────────────────────
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body
    if (!refreshToken) {
      return res.status(400).json({ success: false, message: 'Refresh token required' })
    }

    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET)

    const { data: stored } = await supabaseAdmin
      .from('refresh_tokens')
      .select('*')
      .eq('token', refreshToken)
      .eq('user_id', decoded.userId)
      .single()

    if (!stored || new Date(stored.expires_at) < new Date()) {
      return res.status(401).json({ success: false, message: 'Invalid or expired refresh token' })
    }

    const { data: user } = await supabaseAdmin
      .from('users')
      .select('id, role, is_active')
      .eq('id', decoded.userId)
      .single()

    if (!user?.is_active) {
      return res.status(403).json({ success: false, message: 'Account deactivated' })
    }

    const tokens = generateTokens(user.id, user.role)

    // Rotate refresh token
    await supabaseAdmin.from('refresh_tokens').delete().eq('token', refreshToken)
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
    await supabaseAdmin.from('refresh_tokens').insert({
      user_id: user.id,
      token: tokens.refreshToken,
      expires_at: expiresAt.toISOString()
    })

    res.json({ success: true, data: tokens })
  } catch (err) {
    res.status(401).json({ success: false, message: 'Invalid refresh token' })
  }
})

// ── POST /api/auth/logout ────────────────────────────────────
router.post('/logout', authenticate, async (req, res) => {
  await supabaseAdmin.from('refresh_tokens').delete().eq('user_id', req.user.id)
  res.json({ success: true, message: 'Logged out successfully' })
})

// ── GET /api/auth/me ─────────────────────────────────────────
router.get('/me', authenticate, async (req, res) => {
  const { data: user } = await supabaseAdmin
    .from('users')
    .select('id, email, full_name, phone, role, is_active, is_verified, avatar_url, created_at')
    .eq('id', req.user.id)
    .single()

  res.json({ success: true, data: user })
})

export default router
