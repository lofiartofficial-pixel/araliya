import { Router } from 'express'
import { supabaseAdmin } from '../db/supabase.js'
import { authenticate, authorize } from '../middleware/auth.js'

const router = Router()

// All admin routes require auth + admin role
router.use(authenticate, authorize('admin'))

// GET /api/admin/dashboard
router.get('/dashboard', async (req, res) => {
  try {
    const [users, suppliers, products, orders, revenue] = await Promise.all([
      supabaseAdmin.from('users').select('id, role', { count: 'exact' }),
      supabaseAdmin.from('suppliers').select('id, is_approved', { count: 'exact' }),
      supabaseAdmin.from('products').select('id, is_active', { count: 'exact' }),
      supabaseAdmin.from('orders').select('id, status, total_amount, created_at', { count: 'exact' }).order('created_at', { ascending: false }).limit(10),
      supabaseAdmin.from('orders').select('total_amount').eq('payment_status', 'paid')
    ])

    const totalRevenue = (revenue.data || []).reduce((s, o) => s + parseFloat(o.total_amount), 0)
    const pendingSuppliers = (suppliers.data || []).filter(s => !s.is_approved).length

    res.json({
      success: true,
      data: {
        stats: {
          total_users: users.count,
          total_suppliers: suppliers.count,
          pending_suppliers: pendingSuppliers,
          total_products: products.count,
          total_orders: orders.count,
          total_revenue: totalRevenue
        },
        recent_orders: orders.data
      }
    })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Dashboard fetch failed' })
  }
})

// GET /api/admin/users
router.get('/users', async (req, res) => {
  try {
    const { role, page = 1, limit = 20 } = req.query
    const from = (parseInt(page) - 1) * parseInt(limit)
    let q = supabaseAdmin
      .from('users')
      .select('id, email, full_name, phone, role, is_active, is_verified, created_at', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(from, from + parseInt(limit) - 1)
    if (role) q = q.eq('role', role)
    const { data, error, count } = await q
    if (error) throw error
    res.json({ success: true, data, pagination: { total: count } })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch users' })
  }
})

// PATCH /api/admin/users/:id — toggle active/verified
router.patch('/users/:id', async (req, res) => {
  try {
    const allowed = ['is_active', 'is_verified', 'role']
    const updates = Object.fromEntries(Object.entries(req.body).filter(([k]) => allowed.includes(k)))
    const { data, error } = await supabaseAdmin.from('users').update(updates).eq('id', req.params.id).select().single()
    if (error) throw error
    res.json({ success: true, data })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Update failed' })
  }
})

// GET /api/admin/suppliers — pending approval
router.get('/suppliers', async (req, res) => {
  try {
    const { approved } = req.query
    let q = supabaseAdmin
      .from('suppliers')
      .select('*, users(full_name, email, phone)')
      .order('created_at', { ascending: false })
    if (approved !== undefined) q = q.eq('is_approved', approved === 'true')
    const { data, error } = await q
    if (error) throw error
    res.json({ success: true, data })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch suppliers' })
  }
})

// PATCH /api/admin/suppliers/:id/approve
router.patch('/suppliers/:id/approve', async (req, res) => {
  try {
    const { is_approved, is_featured } = req.body
    const updates = {}
    if (is_approved !== undefined) updates.is_approved = is_approved
    if (is_featured !== undefined) updates.is_featured = is_featured

    const { data, error } = await supabaseAdmin
      .from('suppliers').update(updates).eq('id', req.params.id).select().single()
    if (error) throw error
    res.json({ success: true, data, message: is_approved ? 'Supplier approved' : 'Supplier rejected' })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Update failed' })
  }
})

// GET /api/admin/orders
router.get('/orders', async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query
    const from = (parseInt(page) - 1) * parseInt(limit)
    let q = supabaseAdmin
      .from('orders')
      .select(`*, buyers:users!buyer_id(full_name, phone), suppliers(business_name)`, { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(from, from + parseInt(limit) - 1)
    if (status) q = q.eq('status', status)
    const { data, error, count } = await q
    if (error) throw error
    res.json({ success: true, data, pagination: { total: count } })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch orders' })
  }
})

// GET /api/admin/products — all products (incl. inactive)
router.get('/products', async (req, res) => {
  try {
    const { data, error } = await supabaseAdmin
      .from('products')
      .select('*, suppliers(business_name)')
      .order('created_at', { ascending: false })
    if (error) throw error
    res.json({ success: true, data })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch products' })
  }
})

// PATCH /api/admin/products/:id/feature
router.patch('/products/:id/feature', async (req, res) => {
  try {
    const { data } = await supabaseAdmin
      .from('products').update({ is_featured: req.body.is_featured }).eq('id', req.params.id).select().single()
    res.json({ success: true, data })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Update failed' })
  }
})

export default router
