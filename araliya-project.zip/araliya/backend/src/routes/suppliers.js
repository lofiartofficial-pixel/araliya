import { Router } from 'express'
import { body, validationResult } from 'express-validator'
import { supabaseAdmin } from '../db/supabase.js'
import { authenticate, authorize } from '../middleware/auth.js'

const router = Router()

// GET /api/suppliers — public list
router.get('/', async (req, res) => {
  try {
    const { category, featured, page = 1, limit = 12 } = req.query
    const from = (parseInt(page) - 1) * parseInt(limit)

    let q = supabaseAdmin
      .from('suppliers')
      .select('id, business_name, category, description, city, logo_url, rating, total_orders, is_featured', { count: 'exact' })
      .eq('is_approved', true)
      .order('is_featured', { ascending: false })
      .order('rating', { ascending: false })
      .range(from, from + parseInt(limit) - 1)

    if (category) q = q.eq('category', category)
    if (featured === 'true') q = q.eq('is_featured', true)

    const { data, error, count } = await q
    if (error) throw error

    res.json({ success: true, data, pagination: { total: count, page: parseInt(page), limit: parseInt(limit) } })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch suppliers' })
  }
})

// GET /api/suppliers/:id
router.get('/:id', async (req, res) => {
  try {
    const { data, error } = await supabaseAdmin
      .from('suppliers')
      .select('*, users(full_name, email)')
      .eq('id', req.params.id)
      .eq('is_approved', true)
      .single()

    if (error || !data) return res.status(404).json({ success: false, message: 'Supplier not found' })
    res.json({ success: true, data })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch supplier' })
  }
})

// POST /api/suppliers/register — supplier creates profile
router.post('/register', authenticate, authorize('supplier'), [
  body('business_name').trim().isLength({ min: 2 }),
  body('category').notEmpty(),
  body('address').notEmpty()
], async (req, res) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() })

  try {
    const existing = await supabaseAdmin.from('suppliers').select('id').eq('user_id', req.user.id).single()
    if (existing.data) return res.status(409).json({ success: false, message: 'Supplier profile already exists' })

    const { business_name, business_reg, category, description, address, city, whatsapp } = req.body

    const { data, error } = await supabaseAdmin
      .from('suppliers')
      .insert({ user_id: req.user.id, business_name, business_reg, category, description, address, city, whatsapp })
      .select()
      .single()

    if (error) throw error
    res.status(201).json({ success: true, message: 'Supplier registered. Pending admin approval.', data })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Registration failed' })
  }
})

// GET /api/suppliers/me/dashboard — supplier dashboard stats
router.get('/me/dashboard', authenticate, authorize('supplier'), async (req, res) => {
  try {
    const { data: supplier } = await supabaseAdmin
      .from('suppliers')
      .select('*')
      .eq('user_id', req.user.id)
      .single()

    if (!supplier) return res.status(404).json({ success: false, message: 'Supplier profile not found' })

    const [productsRes, ordersRes, revenueRes] = await Promise.all([
      supabaseAdmin.from('products').select('id, is_active', { count: 'exact' }).eq('supplier_id', supplier.id),
      supabaseAdmin.from('orders').select('id, status, total_amount, created_at', { count: 'exact' }).eq('supplier_id', supplier.id),
      supabaseAdmin.from('orders').select('total_amount').eq('supplier_id', supplier.id).eq('payment_status', 'paid')
    ])

    const totalRevenue = (revenueRes.data || []).reduce((sum, o) => sum + parseFloat(o.total_amount), 0)
    const statusCounts = (ordersRes.data || []).reduce((acc, o) => {
      acc[o.status] = (acc[o.status] || 0) + 1
      return acc
    }, {})

    res.json({
      success: true,
      data: {
        supplier,
        stats: {
          total_products: productsRes.count || 0,
          active_products: (productsRes.data || []).filter(p => p.is_active).length,
          total_orders: ordersRes.count || 0,
          total_revenue: totalRevenue,
          order_status: statusCounts
        }
      }
    })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch dashboard' })
  }
})

// PUT /api/suppliers/me — update own profile
router.put('/me', authenticate, authorize('supplier'), async (req, res) => {
  try {
    const allowed = ['business_name', 'description', 'address', 'city', 'whatsapp', 'logo_url']
    const updates = Object.fromEntries(Object.entries(req.body).filter(([k]) => allowed.includes(k)))

    const { data, error } = await supabaseAdmin
      .from('suppliers')
      .update(updates)
      .eq('user_id', req.user.id)
      .select()
      .single()

    if (error) throw error
    res.json({ success: true, data })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Update failed' })
  }
})

export default router
