import { Router } from 'express'
import { body, validationResult } from 'express-validator'
import { supabaseAdmin } from '../db/supabase.js'
import { authenticate, authorize } from '../middleware/auth.js'
import { sendWhatsAppNotification } from '../services/whatsapp.js'

const router = Router()

// ── POST /api/orders ──────────────────────────────────────────
router.post('/', authenticate, authorize('buyer', 'admin'), [
  body('supplier_id').isUUID(),
  body('items').isArray({ min: 1 }),
  body('items.*.product_id').isUUID(),
  body('items.*.quantity').isInt({ min: 1 }),
  body('delivery_address').notEmpty(),
  body('payment_method').isIn(['bank_transfer', 'cash_on_delivery', 'online'])
], async (req, res) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() })
  }

  try {
    const { supplier_id, items, delivery_address, payment_method, notes } = req.body

    // Validate products & calculate total
    let total_amount = 0
    const validatedItems = []

    for (const item of items) {
      const { data: product } = await supabaseAdmin
        .from('products')
        .select('id, name, price, moq, stock, is_active, supplier_id')
        .eq('id', item.product_id)
        .single()

      if (!product || !product.is_active) {
        return res.status(400).json({ success: false, message: `Product not found: ${item.product_id}` })
      }
      if (product.supplier_id !== supplier_id) {
        return res.status(400).json({ success: false, message: 'All items must be from same supplier' })
      }
      if (item.quantity < product.moq) {
        return res.status(400).json({
          success: false,
          message: `Minimum order for "${product.name}" is ${product.moq} units`
        })
      }
      if (product.stock > 0 && item.quantity > product.stock) {
        return res.status(400).json({
          success: false,
          message: `Insufficient stock for "${product.name}"`
        })
      }

      total_amount += product.price * item.quantity
      validatedItems.push({ product_id: item.product_id, quantity: item.quantity, unit_price: product.price, name: product.name })
    }

    // Create order
    const { data: order, error: orderError } = await supabaseAdmin
      .from('orders')
      .insert({
        buyer_id: req.user.id,
        supplier_id,
        total_amount,
        delivery_address,
        payment_method,
        notes
      })
      .select()
      .single()

    if (orderError) throw orderError

    // Insert order items
    const orderItems = validatedItems.map(item => ({
      order_id: order.id,
      product_id: item.product_id,
      quantity: item.quantity,
      unit_price: item.unit_price
    }))

    await supabaseAdmin.from('order_items').insert(orderItems)

    // Fetch supplier for notification
    const { data: supplier } = await supabaseAdmin
      .from('suppliers')
      .select('business_name, whatsapp')
      .eq('id', supplier_id)
      .single()

    // Send WhatsApp notification
    const itemsList = validatedItems.map(i => `• ${i.name} × ${i.quantity}`).join('\n')
    await sendWhatsAppNotification({
      to: supplier?.whatsapp,
      message: `🌺 *Araliya — New Order!*\n\nOrder: *${order.order_number}*\nBuyer: ${req.user.full_name}\nItems:\n${itemsList}\n\nTotal: *LKR ${total_amount.toLocaleString()}*\n\nDelivery: ${delivery_address}\n\nLogin to manage: https://araliya.lk/dashboard`
    })

    // Update wa_notified
    await supabaseAdmin.from('orders').update({ wa_notified: true }).eq('id', order.id)

    res.status(201).json({
      success: true,
      message: 'Order placed successfully',
      data: { order, items: orderItems }
    })
  } catch (err) {
    console.error('Order error:', err)
    res.status(500).json({ success: false, message: 'Failed to place order' })
  }
})

// ── GET /api/orders ───────────────────────────────────────────
router.get('/', authenticate, async (req, res) => {
  try {
    const { status, page = 1, limit = 10 } = req.query
    const pageNum = Math.max(1, parseInt(page))
    const limitNum = Math.min(50, parseInt(limit))
    const from = (pageNum - 1) * limitNum

    let q = supabaseAdmin
      .from('orders')
      .select(`
        id, order_number, status, total_amount, payment_method,
        payment_status, wa_notified, created_at, delivery_address,
        order_items ( id, quantity, unit_price, subtotal, products(name, images) ),
        buyers:users!buyer_id ( full_name, phone, email ),
        suppliers ( business_name, whatsapp )
      `, { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(from, from + limitNum - 1)

    // Scope by role
    if (req.user.role === 'buyer') q = q.eq('buyer_id', req.user.id)
    else if (req.user.role === 'supplier') {
      const { data: supplier } = await supabaseAdmin
        .from('suppliers').select('id').eq('user_id', req.user.id).single()
      if (supplier) q = q.eq('supplier_id', supplier.id)
    }

    if (status) q = q.eq('status', status)

    const { data, error, count } = await q
    if (error) throw error

    res.json({
      success: true,
      data,
      pagination: { total: count, page: pageNum, limit: limitNum, pages: Math.ceil(count / limitNum) }
    })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch orders' })
  }
})

// ── GET /api/orders/:id ───────────────────────────────────────
router.get('/:id', authenticate, async (req, res) => {
  try {
    const { data, error } = await supabaseAdmin
      .from('orders')
      .select(`
        *, 
        order_items ( *, products(name, images, category) ),
        buyers:users!buyer_id ( id, full_name, phone, email ),
        suppliers ( id, business_name, whatsapp, logo_url )
      `)
      .eq('id', req.params.id)
      .single()

    if (error || !data) return res.status(404).json({ success: false, message: 'Order not found' })

    // Access check
    const isBuyer = req.user.role === 'buyer' && data.buyers?.id === req.user.id
    const isAdmin = req.user.role === 'admin'
    if (!isBuyer && !isAdmin) {
      const { data: s } = await supabaseAdmin.from('suppliers').select('id').eq('user_id', req.user.id).single()
      if (!s || s.id !== data.supplier_id) {
        return res.status(403).json({ success: false, message: 'Access denied' })
      }
    }

    res.json({ success: true, data })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch order' })
  }
})

// ── PATCH /api/orders/:id/status ──────────────────────────────
router.patch('/:id/status', authenticate, authorize('supplier', 'admin'), [
  body('status').isIn(['confirmed', 'processing', 'shipped', 'delivered', 'cancelled'])
], async (req, res) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() })

  try {
    const { status, notes } = req.body

    const { data: order } = await supabaseAdmin
      .from('orders')
      .select('*, buyers:users!buyer_id(full_name, phone), suppliers(business_name, whatsapp)')
      .eq('id', req.params.id)
      .single()

    if (!order) return res.status(404).json({ success: false, message: 'Order not found' })

    const { data: updated } = await supabaseAdmin
      .from('orders')
      .update({ status, ...(notes && { notes }) })
      .eq('id', req.params.id)
      .select()
      .single()

    // Notify buyer via WhatsApp
    const statusEmoji = { confirmed: '✅', processing: '⚙️', shipped: '🚚', delivered: '🎉', cancelled: '❌' }
    await sendWhatsAppNotification({
      to: order.buyers?.phone ? `whatsapp:+94${order.buyers.phone.replace(/^0/, '')}` : null,
      message: `🌺 *Araliya Update*\n\nOrder *${order.order_number}* is now ${statusEmoji[status] || ''} *${status.toUpperCase()}*\n\nFrom: ${order.suppliers?.business_name}\n\nThank you for choosing Araliya! 🌸`
    })

    res.json({ success: true, data: updated })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update status' })
  }
})

export default router
