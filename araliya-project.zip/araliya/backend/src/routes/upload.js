import { Router } from 'express'
import multer from 'multer'
import sharp from 'sharp'
import { v4 as uuidv4 } from 'uuid'
import path from 'path'
import fs from 'fs'
import { supabaseAdmin } from '../db/supabase.js'
import { authenticate } from '../middleware/auth.js'

const router = Router()

// Ensure upload dir exists
const uploadDir = 'uploads'
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true })

const storage = multer.memoryStorage()
const upload = multer({
  storage,
  limits: { fileSize: parseInt(process.env.MAX_FILE_SIZE) || 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp/
    if (allowed.test(path.extname(file.originalname).toLowerCase()) && allowed.test(file.mimetype)) {
      cb(null, true)
    } else {
      cb(new Error('Only image files (JPEG, PNG, WebP) are allowed'))
    }
  }
})

// POST /api/upload/image
router.post('/image', authenticate, upload.single('image'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' })

    const filename = `${uuidv4()}.webp`
    const filepath = path.join(uploadDir, filename)

    // Optimize image with sharp
    await sharp(req.file.buffer)
      .resize(800, 800, { fit: 'inside', withoutEnlargement: true })
      .webp({ quality: 85 })
      .toFile(filepath)

    const imageUrl = `${process.env.BACKEND_URL || 'http://localhost:5000'}/uploads/${filename}`

    res.json({ success: true, url: imageUrl, filename })
  } catch (err) {
    console.error('Upload error:', err)
    res.status(500).json({ success: false, message: 'Upload failed' })
  }
})

// POST /api/upload/multiple
router.post('/multiple', authenticate, upload.array('images', 5), async (req, res) => {
  try {
    if (!req.files?.length) return res.status(400).json({ success: false, message: 'No files uploaded' })

    const urls = []
    for (const file of req.files) {
      const filename = `${uuidv4()}.webp`
      const filepath = path.join(uploadDir, filename)
      await sharp(file.buffer).resize(800, 800, { fit: 'inside' }).webp({ quality: 85 }).toFile(filepath)
      urls.push(`${process.env.BACKEND_URL || 'http://localhost:5000'}/uploads/${filename}`)
    }

    res.json({ success: true, urls })
  } catch (err) {
    res.status(500).json({ success: false, message: 'Upload failed' })
  }
})

export default router
